# Files:
* main.py - creating and learning the NN
* utils.py - some methods that are used in main.py
* test.py - simple script for generating some graphs etc.
* models/ - folder with learned models
* pictures/ - pictures generated using test.py script